$(document).ready(function(){
    $(".owl-carousel").owlCarousel({
        items:1,
        loop:true,
        // margin:18,
        center:true,
        // stagePadding:50,
        merge:true,
        // nav:true,
        rewind:true,
        autoplay:true,
        autoplayTimeout:2000,
        autoplaySpeed:2000,
        autoplayHoverPause:true,
        responsive:{
            0:{
                items:1
            },
            600:{
                item:2
            },
            1000:{
                item:3
            }
        },
        animateIn:'animate__lightSpeedInRight',
        animateOut:'animate__bounceOutLeft'
    });
  });